const input = document.getElementById('videoFile');
const status = document.getElementById('fileStatus');
const selected = document.getElementById('selectedFile');

input.addEventListener('change', async () => {
  const file = input.files && input.files[0];
  if (!file) return;

  const size = (file.size / (1024 * 1024)).toFixed(1);
  selected.hidden = false;
  selected.textContent = `Selected: ${file.name} (${size} MB)`;
  status.textContent = 'Uploading to ClipGenius AI…';

  const form = new FormData();
  form.append('video', file);

  try {
    const response = await fetch('/api/videos', { method: 'POST', body: form });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'Upload failed');

    selected.textContent = `✓ Uploaded: ${result.video.originalName}`;
    selected.dataset.videoId = result.video.id;
    status.textContent = 'Upload complete. Basic clip generation can now be tested from the API.';
  } catch (error) {
    status.textContent = error.message + ' — make sure the ClipGenius server is running.';
  }
});

document.getElementById('year').textContent = new Date().getFullYear();
